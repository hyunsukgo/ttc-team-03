import React from 'react';
import ReactDOM from 'react-dom';

import { Pointers } from './pointers';

ReactDOM.render(<Pointers />, document.getElementById('ordering-app'));
