# Notice! Do not place your custom translation files here.

Storefront will look in this directory for translations as a fallback. It is however recommended that you use the global WordPress language directory and install your translations like so: `/wp-content/languages/themes/storefront-it_IT.mo`. That way they will not be lost or overwritten during Storefront updates.

Alternatively you can put translations in your child theme: `/wp-content/themes/your-child-theme/languages/it_IT.mo`.

You can read more about installing Storefront in your language [here](http://docs.woocommerce.com/document/installing-storefront-in-your-language/).